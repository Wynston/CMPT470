package com.apple.eawt;

import java.util.EventListener;

public interface ApplicationListener extends EventListener {
}
