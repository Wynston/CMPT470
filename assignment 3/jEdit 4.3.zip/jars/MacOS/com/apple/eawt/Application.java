package com.apple.eawt;

public class Application {
	public void addApplicationListener(ApplicationListener al) { }
	public void setEnabledPreferencesMenu(boolean b) { }
	public void setEnabledAboutMenu(boolean b) { }
}
