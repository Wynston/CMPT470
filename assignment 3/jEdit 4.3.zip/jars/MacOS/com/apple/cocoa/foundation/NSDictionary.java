package com.apple.cocoa.foundation;

public class NSDictionary extends NSObject implements NSCoding
{
	public native Object objectForKey(Object o);
}
