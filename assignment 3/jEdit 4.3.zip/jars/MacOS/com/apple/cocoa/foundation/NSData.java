package com.apple.cocoa.foundation;

public class NSData extends NSObject implements NSCoding
{
}
