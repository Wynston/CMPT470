package com.apple.cocoa.foundation;

public class NSAppleEventDescriptor extends NSObject
{
}
