package com.apple.cocoa.application;

import com.apple.cocoa.foundation.NSCoding;

public interface _NSObsoleteMenuItemProtocol extends NSCoding, NSValidatedUserInterfaceItem
{
}
