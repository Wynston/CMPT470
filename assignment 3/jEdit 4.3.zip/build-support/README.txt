This directory contains common ant build tasks for 
building plugins.

